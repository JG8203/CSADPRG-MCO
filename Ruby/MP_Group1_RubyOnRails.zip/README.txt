********************
Last names: Gilo
Language: Ruby on Rails
Paradigm(s): OOP, Imperative, Procedural, Event-Driven, Reflective, Declarative
********************
