module ApplicationHelper
  include ActionView::Helpers::NumberHelper
end
